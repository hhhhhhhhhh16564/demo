//
//  ViewController.m
//  二维码
//
//  Created by yanbo on 17/9/5.
//  Copyright © 2017年 zhl. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)a1:(id)sender {
}
- (IBAction)a2:(id)sender {
}
- (IBAction)a3:(id)sender {
}

- (IBAction)a4:(id)sender {
}
- (IBAction)a5:(id)sender {
}


@end
